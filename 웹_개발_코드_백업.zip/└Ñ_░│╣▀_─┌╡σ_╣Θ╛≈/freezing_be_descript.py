from flask import Flask, request, jsonify
import joblib
import numpy as np

# Flask 앱 초기화
app = Flask(__name__)

# 사전 학습된 모델 로드
# 모델 파일은 "model.pkl"로 저장되어 있어야 함
model = joblib.load("model.pkl")

@app.route("/api/predict", methods=["POST"])
def predict():
    """
    클라이언트에서 데이터를 받아 모델로 예측을 수행하는 API 엔드포인트
    """
    data = request.get_json()  # 클라이언트에서 JSON 형식의 데이터를 수신
    try:
        # 입력 데이터를 numpy 배열로 변환하고 모델 입력 형식에 맞게 재구성
        input_data = np.array(data["features"]).reshape(1, -1)
        
        # 모델을 사용하여 예측 수행
        prediction = model.predict(input_data)
        
        # 예측 결과를 JSON 응답으로 반환
        response = {"prediction": prediction.tolist()}
        return jsonify(response), 200
    except Exception as e:
        # 에러 발생 시 에러 메시지를 JSON으로 반환
        return jsonify({"error": str(e)}), 400

if __name__ == "__main__":
    # Flask 서버 실행
    # "0.0.0.0"은 모든 네트워크 인터페이스에서 접근 가능하도록 설정
    app.run(host="0.0.0.0", port=5000)
